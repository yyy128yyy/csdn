from pyspark.sql import SparkSession
import findspark
from pyecharts import options as opts
from pyecharts.charts import Radar
from pyecharts.commons.utils import JsCode

findspark.init()
spark=SparkSession.builder.appName("data_processing").getOrCreate()

def draw_Radar(data_radar):
    scope=[]

    for col in range(1, data_radar.shape[1]):
        dic = {}
        dic['name'] = data_radar.columns[col]
        dic['max'], dic['min'] = max(data_radar.iloc[:, col]), 0
        scope.append(dic)
    c = (
        # Radar()
        Radar(init_opts=opts.InitOpts(bg_color={"type": "pattern", "image": JsCode("img"), "repeat": "no-repeat"}))
            .add_js_funcs("""    var img = new Image();
                              img.src = '����.jpg';    """)
            .add_schema(
            schema=scope,
            shape="circle",
            center=["50%", "50%"],  # ���ߣ�900px*500px
            radius="60%",
            angleaxis_opts=opts.AngleAxisOpts(
                min_=0,
                max_=360,
                is_clockwise=False,
                interval=10,
                axistick_opts=opts.AxisTickOpts(is_show=True),
                axislabel_opts=opts.LabelOpts(is_show=True),
                axisline_opts=opts.AxisLineOpts(is_show=True),
                splitline_opts=opts.SplitLineOpts(is_show=True)
            ),
            radiusaxis_opts=opts.RadiusAxisOpts(
                min_=0,
                max_=30,
                interval=5,
                splitarea_opts=opts.SplitAreaOpts(
                    is_show=True, areastyle_opts=opts.AreaStyleOpts(opacity=1)
                ),
            ),
            polar_opts=opts.PolarOpts(),
            splitline_opt=opts.SplitLineOpts(is_show=False)
        )
            .add(
            series_name="����",
            data=data_radar[0],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#fc5a50'
        )
            .add(
            series_name="ӡ��",
            data=data_radar[1],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#35ad6b'
        )
            .add(
            series_name="����",
            data=data_radar[2],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#3d7afd'
        )
            .add(
            series_name="����",
            data=data_radar[3],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#aa23ff'
        )
            .add(
            series_name="�¹�",
            data=data_radar[4],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#b865c6'
        )
            .add(
            series_name="Ӣ��",
            data=data_radar[4],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#fcb001'
        )
            .add(
            series_name="����˹",
            data=data_radar[4],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#4cc1f5'
        )
            .add(
            series_name="����",
            data=data_radar[4],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#fcb001'
        )
            .add(
            series_name="�����",
            data=data_radar[4],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#fd854a'
        )
            .add(
            series_name="������",
            data=data_radar[4],
            areastyle_opts=opts.AreaStyleOpts(opacity=0.2),
            linestyle_opts=opts.LineStyleOpts(width=2),
            color='#ED4D83'
        )

            .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
            .set_global_opts(title_opts=opts.TitleOpts(title='Ա������', subtitle='����ͷss', pos_left='left'))
            .render("�״�ͼʾ��.html")
    )
if __name__ == '__main__':
    df=spark.read.csv('forien_data.csv',inferSchema=True,header=True).sort(["�ۼ�ȷ��"]).collect()[:10]
    draw_Radar(df)