from lxml import etree
import json
import requests
import pandas as pd

#爬取的网址（百度疫情）
url="https://voice.baidu.com/act/newpneumonia/newpneumonia/?from=osari_pc_3"
#伪装请求头
headers ={'User-Agent':'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'}
#获取网页地址
response=requests.get(url,timeout=30,headers=headers)
print(response.text)
html=etree.HTML(response.text)
#在网页中寻找我们想要的数据（可以找到对应标签右键复制xpath）
result=html.xpath('//*[@id="captain-config"]/text()')
#print(result)
#result[0]不是真正的字典类型，而是json字符串
#需要通过json.loads转化json字符串为Python的字典类型
result=json.loads(result[0])
#print(result)
#一层一层找自己所用到的数据
result_out=result["component"][0]
print(result_out)

#获取国内疫情数据（找到了
result_in=result["component"][0]["caseList"]
# print(result_in)

ws=[]
#用append生成表第一行
time=result["component"][0]['mapLastUpdatedTime']
#循环遍历数据，按照位置顺序，将数据加入到excel中
for each in result_in:
    temp_list=[each['area'],each['confirmed'],each['died'],each['crued'],each['confirmedRelative']]
    ws.append(temp_list)
ws_df=pd.DataFrame(ws)
ws_df.to_csv("china_data.csv",mode="a", index=False, encoding='utf_8_sig',header=['国家','累计确诊','死亡','治愈','新增'])


#获取国外疫情数据
result_for=result["component"][0]['caseOutsideList']
fws=[]
#循环遍历数据，按照位置顺序，将数据加入到excel中
for each in result_for:
    temp_list=[each['area'],each['confirmed'],each['died'],each['crued'],each['confirmedRelative']]
    fws.append(temp_list)
fws_df = pd.DataFrame(fws)
fws_df.to_csv("forien_data.csv", mode="a", index=False, encoding='utf_8_sig',header=['国家','累计确诊','死亡','治愈','新增'])
