import requests
from lxml import etree
import pandas as pd

url=' https://top.zol.com.cn/compositor/57/cell_phone.html'
header={
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
}
# 内存、电池、屏幕尺寸、分辨率、价格、上市日期、外形(长、宽、厚、重)、存储空间、前置摄像头像素
res=requests.get(url,headers=header)
res=etree.HTML(res.text)
comment_list=[]
urls=res.xpath('/html/body/div[4]/div[3]/div/div[2]/div/div[3]/div/a/@href')
for li in urls:
    # print(li)
    id=li.split("index")[1].split(".")[0]
    url1='https://detail.zol.com.cn/1393/{}/param.shtml'.format(id)
    res1 = requests.get(url1,headers=header)
    res1 = etree.HTML(res1.text)
    name=res1.xpath('/html/body/div[6]/h1/text()')[0].replace('参数','')
    stime=res1.xpath('//*[@id="newPmVal_0"]/text()')[0]
    price=res1.xpath('//*[@id="param-list-b2c-jd"]/text()')[0]
    length=str(res1.xpath('//*[@id="newPmVal_7"]/text()')).replace('[','').replace(']','')
    width=str(res1.xpath('//*[@id="newPmVal_8"]/text()')).replace('[','').replace(']','')
    thickness=str(res1.xpath('//*[@id="newPmVal_9"]/text()')).replace('[','').replace(']','')
    weight=str(res1.xpath('//*[@id="newPmVal_10"]/text()')).replace('[','').replace(']','')
    # 内存、电池、屏幕尺寸、分辨率、价格、上市日期、外形(长、宽、厚、重)、存储空间、前置摄像头像素
    rom=res1.xpath('/html/body/div[9]/div[2]/ul/li[4]/div[1]/a/text()')[0]
    ram=res1.xpath('//*[@id="newPmVal_17"]/a/text()')
    if len(ram)==0 or "GB" not in str(ram):
        ram=res1.xpath('//*[@id="newPmVal_16"]/a/text()')
        if len(ram) == 0 or "GB" not in str(ram):
            ram = res1.xpath('//*[@id="newPmVal_14"]/a/text()')
            if len(ram) == 0 or "GB" not in str(ram):
                ram = res1.xpath('//*[@id="newPmVal_15"]/a/text()')
    ram=str(ram).replace('[','').replace(']','').replace('>','')
    size=res1.xpath('/html/body/div[9]/div[2]/ul/li[6]/div[1]/span[1]/text()')[0]
    battery=res1.xpath('/html/body/div[9]/div[2]/ul/li[5]/div[1]/span[1]/text()')[0]
    before_px=res1.xpath('//div[@class="info-list-fr"]/ul/li[3]//a[@class="product-link"]/text()')#/html/body/div[9]/div[2]
    if len(before_px) == 0:
        before_px = res1.xpath('/html/body/div[9]/div[2]/ul/li[3]/div[1]/span[1]/text()')
        if len(before_px) == 0:
            before_px = res1.xpath('/html/body/div[9]/div[2]/ul/li[3]/div[1]/span[1]/text()')
            #/html/body/div[9]/div[2]/ul/li[3]/div[1]/span[1]
    before_px=str(before_px).replace('[','').replace(']','')
    comment_list.append([id,name,stime,price,length,width,thickness,weight,rom,ram,size,battery,before_px])

comment_dataframe = pd.DataFrame(comment_list)  # 利用pandas将列表转换成dataframe类型
# 保存爬取的评论为csv格式。路径根据自己的情况定。解码格式为：utf_8_sig，否则打开的csv是乱码。
comment_dataframe.to_csv('phone.csv', mode="a", index=False, encoding='utf_8_sig',header=['id','name','上市日期','价格','长','宽','厚','重','内存','运存','尺寸','电池','前置像素'])

