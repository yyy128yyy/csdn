from flask import Flask, render_template, request, jsonify
from flask_bootstrap import Bootstrap
from flask import url_for, session, redirect, flash
from flask_wtf import FlaskForm
from werkzeug.security import generate_password_hash, check_password_hash
from wtforms import StringField, SubmitField, PasswordField, BooleanField, validators
from wtforms.validators import InputRequired, Length
from flask_moment import Moment
from flask_sqlalchemy import SQLAlchemy, os
import os

#注册flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'hard to guess string'
bootstrap = Bootstrap(app)
moment = Moment(app)
# 配置数据库
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, "my.db")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
db = SQLAlchemy(app)
#检查是否登录的装饰器
from functools import wraps
class required_login(object):
    def __call__(self, func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            # print(session['user'])
            try:
                if session['user']==None:
                    pass
            except:
                return redirect(url_for("login"))
            return func(*args,**kwargs)
        return wrapped_function

    def notify(self):
        # logit只打日志，不做别的
        pass
"""页面登录部分"""

#用户登录部分
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True)
    password_hash = db.Column()
    role_id = db.Column(db.Integer)

    def __repr__(self):
        return '<User %r>' % self.username

    @property
    def password(self):
        raise AttributeError('Password is not a readable attribute.')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    # 函数 check_password_hash 检查给出的hash密码与传入的密码是否相符
    def check_password_hash(self, password):
        return check_password_hash(self.password_hash, password)


# 注册表格设计
class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=8, max=16)])
    pwd = PasswordField('New Password', validators=[validators.InputRequired(),
                                                    validators.EqualTo('confirm', message='Passwords must match')])
    confirm = PasswordField('Repeat Password')
    accept_tos = BooleanField('I accept the T0S', [validators.InputRequired()])
    submit = SubmitField('submit')


# 注册页面，登录页面同理
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        #使用前面定义的User类进行过滤：是否username和输入的username相同
        user = User.query.filter_by(username=form.username.data).first()

        if user is None:
            user = User(username=form.username.data, password=form.pwd.data)
            db.session.add(user)
            # 添加多个信息到session中
            db.session.commit()
            # 提交数据库的修改(包括增 / 删 / 改)
            flash("Registered successfully!")
            session['known'] = False
            # print(user)
        else:
            session['known'] = True
            flash("Already Registered!")
        return redirect(url_for('login'))
    return render_template('register.html',
                           form=form)

#登录表格form设计--对应网页的表格
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=8, max=16)])
    pwd = PasswordField(validators=[validators.InputRequired()])
    submit = SubmitField('submit')

#登录页
@app.route("/login", methods=['GET', "POST"])
def login():
    #使用上面生成的表格作为表格
    form = LoginForm()
    #get方法请求--申请登录页面
    if request.method == "GET":
        return render_template("login.html", form=form)
    #通过表单数据获取用户数据
    user = User.query.filter_by(username=form.username.data)
    try:

        pwd = User.query.filter_by(username=form.username.data).all()[0].password_hash
    except :
        pwd = ""
    #如果存在该用户，把用户的名字存入session
    if user != [] and check_password_hash(pwd, form.pwd.data):
        session['user'] = form.username.data
        # print(session.values())
        return redirect(url_for("index"))
    return render_template("login.html", form=form,error="账号或密码错误")

#退出登录
@app.route('/layout')
def layout():
    #把用户的session置空
    session['user'] = None
    #返回登录页
    return redirect(url_for("login"))


# 错误页面
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

# 错误页面
@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500


# 首页（应该支持判断是否登录，登录展示用户名，未登录显示登录）
@app.route('/')
def index():
    return render_template("index.html")

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
