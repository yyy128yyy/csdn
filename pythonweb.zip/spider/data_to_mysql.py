import pandas as pd
import pymysql
import csv
import codecs
file_path = "new_51job.csv"
data = pd.read_csv(file_path, encoding='utf-8')
def get_conn():
    db = pymysql.connect(host='localhost',
                         user='root',
                         password='123456',
                         database='job51',
                         charset='utf8')
    return db
def insert(cur, sql, args):
    try:
        cur.execute(sql, args)
    except Exception as e:
        print(e)
def read_csv_to_mysql(filename):
    '''
    csv文件->数据库
    :param filename:
    :return:
    '''
    with codecs.open(filename=filename, mode='r', encoding='utf-8') as f:
        reader = csv.reader(f)
        head = next(reader)
        # print(head)
        conn = get_conn()
        cur = conn.cursor()
        sql = 'insert into job(job_name, company_name, job_city, expirence, degree, salary_degree, walfare, work_detail, work_information, work_type) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        for item in reader:
            # if item[1] is None or item[1] == '':  # item[1]作为唯一键，不能为null
            #     continue
            args = tuple(item)
            # print(args)
            insert(cur, sql=sql, args=args)
        conn.commit()
        cur.close()
        conn.close()
if __name__ == '__main__':
    read_csv_to_mysql("new_51job.csv")