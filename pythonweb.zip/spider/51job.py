import time
import requests
from lxml.etree import HTML
import os
import pandas as pd
from sqlalchemy import create_engine
#对爬取的数据进行初步调整
def check(a):
    经验=''
    学历=''
    for i in a:
        if '经验' in i or '在校生' in i:
            经验=i
            continue
        if '硕士' in i or '大专' in i or '本科' in i or '高中' in i or '初中' in i or '博士' in i:
            学历 = i
            continue

    return 经验,学历
#输入cookie进行数据爬取
cookie1=input('请输入列表cookie:')
#输入页码
startpage=input('请输入开始页码:')
endpage=input('请输入开始页码:')
#循环页码开始爬虫
for page in range(int(startpage),int(endpage)):
    url=f'https://search.51job.com/list/000000,000000,0121%252c0122%252c0124%252c2707%252c7201,01,0,99,+,2,{page}.html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare='
    headers1 = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Cookie': cookie1,
        'Host': 'search.51job.com',
        'Pragma': 'no-cache',
        'Referer': 'https://search.51job.com/list/000000,000000,0121%252c0122%252c0124%252c2707%252c7201,01,9,99,+,2,2.html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare=',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
    }
    headers2 = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Cookie': cookie1,
        'Host': 'jobs.51job.com',
        'Pragma': 'no-cache',
        'Referer': 'https://jobs.51job.com/suzhou-gyyq/139429283.html?s=sou_sou_soulb&t=0_0',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36',
    }
    #获取数据，并且分别把数据放进去
    res=requests.get(url,headers=headers1).json()
    for i in res['engine_jds']:
        company_name=i['company_name']
        job_title=i['job_title']
        providesalary_text=i['providesalary_text']
        updatedate=i['updatedate']
        workarea_text=i['workarea_text']
        attribute_text=i['attribute_text']
        经验, 学历 = check(attribute_text)
        jobwelf=i['jobwelf']
        job_href=i['job_href']
        res_href = requests.get(job_href, headers=headers2).content
        try:
            res_href=res_href.decode('gbk')
        except:
            res_href = res_href.decode('utf8')
        if '滑动验证页面' in res_href:
            print('出现滑动检测请注意****************************************')
        zhiwei=''.join(HTML(res_href).xpath(r'//div[@class="bmsg job_msg inbox"]//text()'))
        leibie = ''.join(HTML(res_href).xpath(r'//div[@class="mt10"]/p[1]/a/text()'))
        #把数据放进去
        data={
            '职位名称': job_title,
            '公司名字': company_name,
            '工作城市': workarea_text,
            '经验要求': 经验,
            '学历要求': 学历,
            '薪资水平': providesalary_text,
            '福利待遇': jobwelf,
            '职位详情页': job_href,
            '职位信息': zhiwei,
            '职能类别': leibie,
        }
        #把数据格式转化为Dataframe
        df=pd.DataFrame([data])
        savepath=r'51job24hour_1.csv'
        if not os.path.exists(savepath):
            df.to_csv(savepath,index=False,mode='a')
        else:
            df.to_csv(savepath, index=False, mode='a', header=None)
        print(data)
        time.sleep(2)
