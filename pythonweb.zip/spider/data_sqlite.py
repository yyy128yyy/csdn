import sqlite3
import time
import pandas as pd
import pymysql
import csv
import codecs
#初始化sqlite的操作的类---这是固定的，综合起来就是连接数据库，提供执行数据库的方法
#execute_sql执行单条数据
#executemany_sql执行多条数据
# sqlite3--
# mysql
class DbOperate(object):
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, "_instance"):
            cls._instance = super(DbOperate, cls).__new__(cls)
        return cls._instance

    def __init__(self, db_name):
        self.db_name = db_name
        self.connect = sqlite3.connect(self.db_name)
        self.cursor = self.connect.cursor()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connect.close()

    def execute_sql(self, sql,values):
        try:
            self.cursor.execute(sql,values)
            self.connect.commit()
        except Exception as e:
            self.connect.rollback()

    def executemany_sql(self, sql, data_list):
        # example:
        # sql = 'insert into filelist (pkgKey, dirname, filenames, filetypes) values (?, ?, ?, ?);'
        # data_list = [(1, '/etc/sysconfig', 'openshift_option', 'f'), (1, '/usr/share/doc', 'adb-utils-1.6', 'd')]
        try:
            self.cursor.executemany(sql, data_list)
            self.connect.commit()
        except Exception as e:
            self.connect.rollback()
            raise Exception("executemany failed")

#sql文件的地址
sqlite_path = "../my.db"
#打开sql文件，执行插入操作
with DbOperate(sqlite_path) as db:
    sql = "insert into job(job_name, company_name, job_city, expirence, degree, salary_degree, walfare, work_detail, work_information, work_type,province) values(?,?,?,?,?,?,?,?,?,?,?)"
    #打开csv文件，分别将数据取出插入数据库
    with codecs.open(filename="new_51job.csv", mode='r', encoding='utf8') as f:
        reader = csv.reader(f)
        head = next(reader)
        # print(head)
        # sql = 'insert into job(job_name, company_name, job_city, expirence, degree, salary_degree, walfare, work_detail, work_information, work_type) values(?,?,?,?,?,?,?,?,?,?)'
        lis = []
        for item in reader:
            lis.append(tuple(item))
        db.executemany_sql(sql, tuple(lis))
            # insert(cur, sql=sql, args=args)