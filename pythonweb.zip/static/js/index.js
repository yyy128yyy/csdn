//地图板块
(function() {
    var ec_center = echarts.init(document.querySelector("#map"));
    var ec_center_option = {
        title: {
            text: '系统使用数据量',
            subtext: '',
            x: 'left',
            textStyle: {
                color: 'rgb(50, 54, 57)',
            },
        },

        tooltip: {
            trigger: 'item'
        },
        //左侧小导航图标
        visualMap: {
            show: true,
            x: 'left',
            y: 'bottom',
            textStyle: {
                fontSize: 8,
            },
            splitList: [{ start: 0,end: 9 },
                {start: 10, end: 99 },
                { start: 100, end: 999 },
                {  start: 1000, end: 9999 }],
            color: ['rgb(230, 88, 91)','rgb(195, 185, 139)','rgb(155, 175, 142)',"rgb(73, 158, 186)"]
        },
        //配置属性
        series: [{
            name: '系统使用数据量',
            type: 'map',
            mapType: 'china',
            roam: false, //拖动和缩放
            itemStyle: {
                normal: {
                    borderWidth: .5, //区域边框宽度
                    borderColor: '#62d3ff', //区域边框颜色
                    areaColor: "#b7ffe6", //区域颜色
                },
                emphasis: { //鼠标滑过地图高亮的相关设置
                    borderWidth: .5,
                    borderColor: '#fff',
                    areaColor: "#fff",
                }
            },
            label: {
                normal: {
                    show: true, //省份名称
                    fontSize: 8,
                },
                emphasis: {
                    show: true,
                    fontSize: 8,
                }
            },
            data:[]//mydata //数据
        }]

    };
    ec_center.setOption(ec_center_option);
    function  get_c1_data(){
    $.ajax({
        url:"/c1",
        success:function (data) {
            $(".num h4").eq(0).text(data.data[0]);
            $(".num h4").eq(1).text(data.data[1]);
            $(".num h4").eq(2).text(data.data[2]);
            $(".num h4").eq(3).text(data.data[3]);
            // $(".num h4").eq(3).text(data[3]);
        }
    })
    }
    function get_c2_data() {
    $.ajax({
        url:"/c2",
        success: function(data) {
			ec_center_option.series[0].data=data.data;
            ec_center_option.series[0].data.push({
      	        name:"南海诸岛",value:0,
      	        itemStyle:{
      		        normal:{ opacity:0},
      	        },
      	        label:{show:false}
            });
            ec_center_option.series[0].data.push({
                    name:"青海",value:0

            });
            ec_center_option.series[0].data.push({
                    name:"西藏",value:0
            });
            ec_center_option.series[0].data.push({
                    name:"宁夏",value:0
            });
            ec_center_option.series[0].data.push({
                    name:"台湾",value:0
            });
            ec_center.setOption(ec_center_option);
		},
		error: function(xhr, type, errorThrown) {

		}
    })
}
    get_c2_data();
  // 监听浏览器缩放，图表对象调用缩放resize函数
    window.addEventListener("resize", function() {
    myChart.resize();
  });
})();

//左上柱状图模块1
(function() {
  // 1实例化对象
  var ec_right2 = echarts.init(document.querySelector("#bar"));
  // 2. 指定配置项和数据
  var ec_r2_option = {
    color: ["#2f89cf"],
    tooltip: {
      trigger: "axis",
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    // 修改图表的大小
    grid: {
      left: "0%",
      top: "10px",
      right: "0%",
      bottom: "4%",
      containLabel: true
    },
    xAxis: [
      {
        type: "category",
        data: [],
        axisTick: {
          alignWithLabel: true
        },
        // 修改刻度标签 相关样式
        axisLabel: {
          color: "rgba(0,0,0,.6)",
          fontSize: "12"
        },
        // 不显示x坐标轴的样式
        axisLine: {
          show: false
        }
      }
    ],
    yAxis: [
      {
        type: "value",
        // 修改刻度标签 相关样式
        axisLabel: {
          color: "rgba(0,0,0,.6)",
          fontSize: 12
        },
        // y轴的线条改为了 2像素
      }
    ],
    series: [
      {
        name: "人数",
        type: "bar",
        barWidth: "35%",
        data: [],
        itemStyle: {
          // 修改柱子圆角
          barBorderRadius: 5
        }
      }
    ]
  };
  // 3. 把配置项给实例对象
  ec_right2.setOption(ec_r2_option);
  // 4. 让图表跟随屏幕自动的去适应
  window.addEventListener("resize", function() {
    ec_right2.resize();
  });
  //5.加载数据
  function get_r2_data() {
    $.ajax({
        url: "/r2",
        success: function (data) {
            ec_r2_option.xAxis[0].data=data.name;

            ec_r2_option.series[0].data=data.value;
            ec_right2.setOption(ec_r2_option);
        }
    });
}
    get_r2_data();
    // 监听浏览器缩放，图表对象调用缩放resize函数
  window.addEventListener("resize", function() {
    ec_right2.resize();
  });
})();

//右下饼形图
(function() {
  var myChart = echarts.init(document.querySelector(".pie"));
  var option = {
    color: [
      "#006cff",
      "#60cda0",
      "#ed8884",
      "#ff9f7f",
      "#0096ff",
      "#9fe6b8",
      "#32c5e9",
      "#1d9dff"
    ],
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b} : {c}000 "
    },
    legend: {
      bottom: "0%",
      itemWidth: 10,
      itemHeight: 10,
      textStyle: {
        color: "black",
        fontSize: "12"
      }
    },
    series: [
      {
        name: "平均薪资",
        type: "pie",
        radius: ["10%", "70%"],
        center: ["50%", "50%"],
        roseType: "radius",
        // 图形的文字标签
        label: {
          fontSize: 10,
         formatter: '{b}',
        },
        // 链接图形和文字的线条
        labelLine: {
          // length 链接图形的线条
          length: 6,
          // length2 链接文字的线条
          length2: 8
        },
        data: []
        /*[{ value: 20, name: "今日新增" },
          { value: 26, name: "今日治愈" },
          { value: 24, name: "今日死亡" },

          { value: 20, name: "云南" },
          { value: 26, name: "北京" },
          { value: 24, name: "山东" },
          { value: 25, name: "河北" },
          { value: 20, name: "江苏" },
          { value: 25, name: "浙江" },
          { value: 30, name: "四川" },
          { value: 42, name: "湖北" }
        ]*///
      }
    ]
  };
    myChart.setOption(option);

    function get_r1_data() {
    $.ajax({
        url: "/r1",
        success: function (data) {
            console.log(data);
            option.series[0].data=data.data;
            myChart.setOption(option);
        }
    });
}
    get_r1_data();

  // 监听浏览器缩放，图表对象调用缩放resize函数
  window.addEventListener("resize", function() {
    myChart.resize();
  });
})();


